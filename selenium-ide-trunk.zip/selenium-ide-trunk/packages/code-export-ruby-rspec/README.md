# code-export-ruby-rspec

Ruby RSpec code export for Selenium IDE.
