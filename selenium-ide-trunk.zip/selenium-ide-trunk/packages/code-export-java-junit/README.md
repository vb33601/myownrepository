# code-export-java-junit

Java JUnit code export for Selenium IDE.
