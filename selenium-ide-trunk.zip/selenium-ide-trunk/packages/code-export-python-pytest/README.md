# code-export-python-pytest

Python pytest code export for Selenium IDE.
