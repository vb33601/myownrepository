import path from 'node:path'

export default path.join(__dirname, '..', 'public', 'index.html')
