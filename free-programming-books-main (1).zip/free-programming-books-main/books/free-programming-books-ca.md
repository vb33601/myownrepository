### Index

* [Algorismes i Estructures de Dades](#algorismes-i-estructures-de-dades)
* [C](#c)
* [Ciències de la Computació](#ciències-de-la-computació)


### Algorismes i Estructures de Dades

* [Apropament a les estructures de dades des del programari lliure](https://repositori.udl.cat/bitstream/handle/10459.1/63471/Eines%20Josep%20M%20Ribo%20electronic.pdf?sequence=1&isAllowed=y) Universitat de Lleida, Josep Maria Ribó (PDF)


### C

* [Programació en C](https://ca.wikibooks.org/wiki/Programaci%C3%B3_en_C) WikiLlibres


### Ciències de la Computació

* [Lògica Proposicional i de Predicats](https://github.com/EbookFoundation/free-programming-books/files/9808381/logica-proposicional-i-predicats.pdf) Universitat de Lleida, Felip Manyà i Serres (PDF)

