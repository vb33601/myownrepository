/**
 * Shows a confirm dialog and passes back the boolean of confirmation
 */
export type Shape = () => Promise<boolean>
