/**
 * Saves the current project to a path
 */
export type Shape = (filepath: string) => Promise<boolean>
