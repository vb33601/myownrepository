/**
 * Shows an open file dialog and passes back the async result
 */
export type Shape = () => Promise<string>
