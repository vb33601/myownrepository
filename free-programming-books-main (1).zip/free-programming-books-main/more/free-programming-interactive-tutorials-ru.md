### Index

* [Веб-разработка](#веб-разработка)
* [Облачные вычисления](#облачные-вычисления)
* [Git](#git)
* [Go](#go)
* [Python](#python)
* [Solidity](#solidity)
* [SQL](#sql)


### Веб-разработка

* [Учитесь веб-разработке бесплатно!](http://codenamecrud.ru)
* [Open source воркшопы](https://nodeschool.io/ru)


### Облачные вычисления

* [Microsoft Certified: Azure Fundamentals](https://docs.microsoft.com/ru-ru/learn/certifications/azure-fundamentals/) - Microsoft


### Git

* [Интерактивное обучение работе с git](https://githowto.com/ru)
* [Обучение git при помощи визуализации](https://learngitbranching.js.org/?locale=ru_RU)


### Go

* [Выполните первые шаги с помощью Go](https://docs.microsoft.com/ru-ru/learn/paths/go-first-steps/) - Microsoft


### Python

* [Pythontutor](https://pythontutor.ru)


### Solidity

* [CryptoZombies.io](https://cryptozombies.io/ru) - Ethereum DApps


### SQL

* [SQL упражнения](https://www.sql-ex.ru/?Lang=0)
