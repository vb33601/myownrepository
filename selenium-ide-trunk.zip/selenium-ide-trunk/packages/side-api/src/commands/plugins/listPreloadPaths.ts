/**
 * Get a list of active plugin preload paths
 */
export type Shape = () => Promise<string[]>
