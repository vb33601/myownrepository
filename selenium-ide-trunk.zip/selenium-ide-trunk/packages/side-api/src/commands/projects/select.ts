/**
 * Used during initialization to load a .side file by double clicking it.
 */
export type Shape = () => Promise<void>
