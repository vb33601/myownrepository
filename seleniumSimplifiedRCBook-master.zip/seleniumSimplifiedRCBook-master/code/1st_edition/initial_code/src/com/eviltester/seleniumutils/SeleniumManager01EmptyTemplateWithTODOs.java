package com.eviltester.seleniumutils;

import com.thoughtworks.selenium.Selenium;

public class SeleniumManager01EmptyTemplateWithTODOs {

	public void start(String string) {
		// TODO Auto-generated method stub
		
	}

	public Selenium getSelenium() {
		// TODO Auto-generated method stub
		return null;
	}

	public void stop() {
		// TODO Auto-generated method stub
		
	}

}
