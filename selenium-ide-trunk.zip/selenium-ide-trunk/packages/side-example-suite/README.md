# SIDE Example Suite

This contains a project with some nice boilerplate around code export and building
custom plugins with types and such.

If you don't care about modifying the export format you're starting from, you can
just import it directly in the bin command:
