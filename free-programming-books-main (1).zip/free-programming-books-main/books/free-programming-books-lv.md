### Index

* [C++](#cpp)
* [Python](#python)


### <a id="cpp"></a>C++

* [Programmēšana un C++](http://home.lu.lv/~janiszu/courses/eprg/eprg.all.pdf) - Jānis Zuters (PDF)
* [Programmēšanas pamati](https://likta.lv/wp-content/uploads/2018/12/Programmesanas_gramata_e-versija.pdf) - Raivis Ieviņš (PDF)


### Python

* [Programmēšanas pamati ar valodu Python](http://home.lu.lv/~janiszu/courses/python/python3.pdf) - Jānis Zuters (PDF)
* [Programmēšanas valoda "Python" iesācējiem](https://www.alvils.info/e-gramatas/programmesanas-valoda-python-iesacejiem/) - Alvils Bērziņš
