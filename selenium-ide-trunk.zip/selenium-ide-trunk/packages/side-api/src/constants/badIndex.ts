export const badIndex = -1
