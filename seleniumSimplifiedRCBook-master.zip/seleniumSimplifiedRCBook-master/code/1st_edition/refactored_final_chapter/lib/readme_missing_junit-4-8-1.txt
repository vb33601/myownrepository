This code used to be supplied as a zip file with junit-4.8.1.jar located in this directory.

The .jar file has been removed, you will need to add it here if you wish to run the code.