---

name: 💬 Questions / Help
about: If you have questions, please check our IRC or Slack
---

## 💬 Questions and Help

### Please note that this issue tracker is not a help form and this issue will be closed.

For questions or help please see:

- [SeleniumHQ IRC channel](https://webchat.freenode.net/)
- [SeleniumHQ Slack channel](https://seleniumhq.herokuapp.com/)
- The [Selenium Users](https://groups.google.com/forum/#!forum/selenium-users) google group
