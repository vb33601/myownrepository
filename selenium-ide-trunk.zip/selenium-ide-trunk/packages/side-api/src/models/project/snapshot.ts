import { SnapshotShape } from '@seleniumhq/side-model'

export const snapshot: SnapshotShape = {
  tests: [],
  dependencies: {},
  jest: {
    extraGlobals: [],
  },
}
