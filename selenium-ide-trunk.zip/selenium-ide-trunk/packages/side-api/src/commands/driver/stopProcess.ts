/**
 * Stop the driver process for the browser
 */
export type Shape = () => Promise<void>
