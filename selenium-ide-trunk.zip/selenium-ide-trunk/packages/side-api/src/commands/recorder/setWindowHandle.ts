/**
 * I am not fully sure what this does. This may be able to go.
 */
export type Shape = (sessionID: string, handle: string) => Promise<void>
