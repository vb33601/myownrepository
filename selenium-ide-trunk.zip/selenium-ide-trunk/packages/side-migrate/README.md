# About

This package is meant to upgrade commands in a project from v3 to v4 effortlessly.

## How to use

Honestly, just do something like this:

`npx @seleniuhq/side-migrate ./existing_file.side ./new_v4_file.side`

After that, your project json should be upgraded to v4. If that doesn't work
right for ya, please raise an issue [here](
  https://github.com/SeleniumHQ/selenium-ide/issues/new?assignees=&labels=&projects=&template=bug.md
)

Thanks!

## Contributing

Oh gee golly! Oh gee willikers batman! What a generous offer! <3 I'd start in contributing [here](
  https://github.com/SeleniumHQ/selenium-ide/issues/new?assignees=&labels=&projects=&template=bug.md
) and you can just go where the flow takes you!
