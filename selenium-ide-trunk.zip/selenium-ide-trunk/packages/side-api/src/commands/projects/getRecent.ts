/**
 * Returns a list of paths to recent projects
 */
export type Shape = () => Promise<string[]>
