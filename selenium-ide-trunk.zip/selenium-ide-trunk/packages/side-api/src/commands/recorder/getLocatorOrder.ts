export type Shape = () => Promise<string[]>
