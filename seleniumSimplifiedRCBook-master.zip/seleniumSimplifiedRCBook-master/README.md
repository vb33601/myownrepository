# Selenium Simplified RC Book

The Selenium Simplified - Java, Selenium-RC, book.

"Selenium Simplified" 1st and 2nd editions are now free.

The pdf is still copyright to Alan Richardson, Compendium Developments and should not be sold or used as the basis for commercial books or courses.

The code is open source and released with no warranty etc.

I first wrote this in 2010 and 2nd edition in 2012. Selenium 3 has deprecated the RC interface - although it still works.

I use WebDriver now, and will not update this book for Selenium 3.

I have put the paperback edition as out of print so only remainders and second hand copies will be available.

And the pdf is no longer for sale.

Thank you to everyone that purchased it.

Support pages for the book remain at http://www.compendiumdev.co.uk/selenium/


You can find my online courses and books at http://compendiumdev.co.uk


