### Index

* [Miscellaneous](#miscellaneous)


### Miscellaneous

* [أخوك الكبير متولي](https://anchor.fm/metwally) - Ahmed Metwally (podcast)
* [برمجة ستريم](https://youtube.com/playlist?list=PL0_C_32YKLpx7K88481CY3J21cw85oFCM) - Mohamed Abusrea (podcast)
* [بودكاست](https://youtube.com/playlist?list=PLvGNfY-tFUN-mGlfovyGACjPVmkzAsQFJ) - Ghareeb Elshaikh (podcast)
* [AskDeveloper Podcast](http://www.askdeveloper.com) - Mohamed Elsherif (podcast)
* [Codezilla Codecast - بودكاست البرمجة](https://youtube.com/playlist?list=PLsqPSxnrsWLuE-O3IKIUWy6Hmelz3bMWy) - Islam Hesham (podcast)
* [Essam Cafe - قهوة عصام](https://essamcafe.com) - Ahmed Essam (podcast)
* [Nakerah Podcast](https://nakerah.net/podcast) - Nakerah Network (podcast)
* [null++: بالعربي](https://nullplus.plus) - Mohamed Luay, Ahmad Alfy (podcast)
* [Tech Podcast بالعربي](https://anchor.fm/ahmdelemam) - Ahmed Elemam (podcast)
* [The Egyptian Guy](https://anchor.fm/refaie) - Mohamed Refaie (podcast)
* [The Weekly Noob](https://theweeklynoob.netlify.app) - Nabil Tharwat (podcast)
* [Untyped Podcast](https://logaretm.com/untyped/) - Abdelrahman Awad (podcast)
  
