/**
 * Close a window by name
 */
export type Shape = (name: string) => Promise<void>
