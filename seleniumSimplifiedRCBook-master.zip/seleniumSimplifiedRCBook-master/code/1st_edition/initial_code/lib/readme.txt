to save space in the zip file I have removed
- junit-4.8.1.jar
- selenium-java-client-driver.jar
- selenium-server.jar

from this folder, so add them back to make this .zip complete (follow book instructions to do this)