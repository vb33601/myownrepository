/**
 * Exits without raising an error
 */
export type Shape = (error: unknown) => Promise<void>
