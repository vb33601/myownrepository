/**
 * Raises an error and exits
 */
export type Shape = (error: unknown) => Promise<void>
