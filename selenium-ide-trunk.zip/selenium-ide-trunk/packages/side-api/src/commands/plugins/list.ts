/**
 * Get a list of active plugins
 */
export type Shape = () => Promise<string[]>
