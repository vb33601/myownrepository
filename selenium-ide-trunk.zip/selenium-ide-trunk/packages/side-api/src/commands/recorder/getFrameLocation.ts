/**
 * Used by the main process to construct the frame tree
 */
export type Shape = () => Promise<string>
