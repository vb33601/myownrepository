export const TESTS_TAB = 0
export const SUITES_TAB = 1
export const PROJECT_TAB = 2

export type TAB = typeof TESTS_TAB | typeof SUITES_TAB | typeof PROJECT_TAB
