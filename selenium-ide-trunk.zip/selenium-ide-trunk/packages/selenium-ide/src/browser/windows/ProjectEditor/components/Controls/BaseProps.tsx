const baseControlProps = {
  className: 'm-2 not-draggable',
  color: 'inherit',
  sx: { borderRadius: 0.5 },
} as const

export default baseControlProps