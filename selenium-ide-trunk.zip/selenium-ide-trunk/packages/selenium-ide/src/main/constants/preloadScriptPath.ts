import path from 'node:path'

export default path.join(__dirname, 'preload-bundle.js')
